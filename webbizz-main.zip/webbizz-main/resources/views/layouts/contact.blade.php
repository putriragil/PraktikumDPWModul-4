@extends('layouts.app')

@section('content')
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <h2>Contact Us</h2>
                <p>You can contact us using the information below:</p>
                <p>Email: example@example.com</p>
                <p>Phone: +123-456-7890</p>
                <p>Address: 123 Example Street, City, Country</p>
            </div>
        </div>
    </div>
@endsection
