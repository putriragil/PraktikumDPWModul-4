@extends('layouts.app')

@section('content')
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <h2>About Us</h2>
                <p>This is the About Us page content. You can provide information about your website or organization here.</p>
            </div>
        </div>
    </div>
@endsection
